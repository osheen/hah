package com.example.temphackathon;

public class conversationData {
    private String userRequest;
    private String botResponse;

    public void setUserRequest(String userRequest) {
        this.userRequest = userRequest;
    }

    public void setBotResponse(String botResponse) {
        this.botResponse = botResponse;
    }

}
